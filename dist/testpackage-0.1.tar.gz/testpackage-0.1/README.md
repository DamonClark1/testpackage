# mypackage
This library was created in order to have some Recursion and Sorting functions all in one package.

## building this package locally
"python setup.py sdist"

## installing this package from GitHub
"pip install git+https://github.com/DamonClark1/testpackage.git"

## updating this package from GitHub
"pip install --upgrade git+https://github.com/DamonClark1/testpackage.git"
